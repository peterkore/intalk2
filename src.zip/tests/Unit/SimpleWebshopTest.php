<?php

namespace Tests\Unit;

use Tests\TestCase;
use Webshop\Model\Product;
use Webshop\Model\Category;
use Webshop\Model\Order;
use Webshop\Model\User;
use Webshop\Model\Address;

class SimpleWebshopTest extends TestCase
{
    public function test_database_structure()
    {
        // Ellenőrizzük, hogy létre tudunk-e hozni egy kategóriát
        $category = new Category();
        $category->setName('Teszt Kategória');
        
        $this->entityManager->persist($category);
        $this->entityManager->flush();
        
        $this->assertNotNull($category->getId(), 'A kategória sikeresen létrejött az adatbázisban');

        // Ellenőrizzük, hogy létre tudunk-e hozni egy terméket
        $product = new Product();
        $product->setName('Teszt Termék');
        $product->setPrice(1000);
        $product->setStock(10);
        $product->setCategory($category);
        
        $this->entityManager->persist($product);
        $this->entityManager->flush();
        
        $this->assertNotNull($product->getId(), 'A termék sikeresen létrejött az adatbázisban');
        $this->assertEquals($category, $product->getCategory(), 'A termék kategóriája megfelelően be van állítva');
    }

    public function test_can_place_order()
    {
        // Létrehozunk egy felhasználót
        $user = new User();
        $user->setName('Teszt Felhasználó');
        $user->setEmail('teszt@example.com');
        $user->setPassword(password_hash('jelszo123', PASSWORD_DEFAULT));
        $this->entityManager->persist($user);
        $this->entityManager->flush();

        $address = new Address();
        $address->setUser($user);
        $address->setName('Teszt Felhasználó');
        $address->setType('shipping');
        $address->setStreet('Teszt utca 1.');
        $address->setCity('Budapest');
        $address->setZipCode('1111');
        $address->setCountry('Magyarország');
        $this->entityManager->persist($address);
        $this->entityManager->flush();

        // Létrehozunk egy terméket
        $product = new Product();
        $product->setName('Teszt Termék');
        $product->setPrice(1000);
        $product->setStock(10);
        
        $this->entityManager->persist($product);
        $this->entityManager->flush();
        
        // Létrehozunk egy rendelést
        $order = new Order();
        $order->setUser($user);
        $order->setStatus('új');
        $order->setTotalAmount(1000);
        $order->setPaymentMethod('készpénz');
        $order->setShippingMethod('házhozszállítás');
        $order->setBillingAddress($address);
        $order->setShippingAddress($address);
        
        $this->entityManager->persist($order);
        $this->entityManager->flush();
        
        $this->assertNotNull($order->getId(), 'A rendelés sikeresen létrejött');
        $this->assertEquals($user, $order->getUser(), 'A rendelés megfelelően kapcsolódik a felhasználóhoz');
        $this->assertEquals(1000, $order->getTotalAmount(), 'A rendelés végösszege helyes');
        $this->assertEquals('készpénz', $order->getPaymentMethod(), 'A fizetési mód megfelelően be van állítva');
        $this->assertEquals('házhozszállítás', $order->getShippingMethod(), 'A szállítási mód megfelelően be van állítva');
        $this->assertEquals($address, $order->getBillingAddress(), 'A számlázási cím megfelelően be van állítva');
        $this->assertEquals($address, $order->getShippingAddress(), 'A szállítási cím megfelelően be van állítva');
    }
} 