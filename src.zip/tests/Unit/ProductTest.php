<?php

namespace Tests\Unit;

use Tests\TestCase;
use Webshop\Model\Product;
use Webshop\Model\Category;

class ProductTest extends TestCase
{
    public function test_can_create_product()
    {
        $category = new Category();
        $category->setName('Test kategória');
        $this->entityManager->persist($category);
        $this->entityManager->flush();

        $product = new Product();
        $product->setName('Test termék');
        $product->setDescription('Test leírás');
        $product->setPrice(1000);
        $product->setStock(10);
        $product->setCategory($category);

        $this->entityManager->persist($product);
        $this->entityManager->flush();

        $this->assertNotNull($product->getId());
        $this->assertEquals('Test termék', $product->getName());
        $this->assertEquals('Test leírás', $product->getDescription());
        $this->assertEquals(1000, $product->getPrice());
        $this->assertEquals(10, $product->getStock());
        $this->assertEquals($category, $product->getCategory());
    }

    public function test_can_update_product()
    {
        $category = new Category();
        $category->setName('Test kategória');
        $this->entityManager->persist($category);
        $this->entityManager->flush();

        $product = new Product();
        $product->setName('Test termék');
        $product->setDescription('Test leírás');
        $product->setPrice(1000);
        $product->setStock(10);
        $product->setCategory($category);

        $this->entityManager->persist($product);
        $this->entityManager->flush();

        $product->setName('Frissített termék');
        $product->setPrice(2000);
        $product->setStock(5);

        $this->entityManager->flush();

        $this->assertEquals('Frissített termék', $product->getName());
        $this->assertEquals(2000, $product->getPrice());
        $this->assertEquals(5, $product->getStock());
    }

    public function test_can_delete_product()
    {
        $category = new Category();
        $category->setName('Test kategória');
        $this->entityManager->persist($category);
        $this->entityManager->flush();

        $product = new Product();
        $product->setName('Test termék');
        $product->setDescription('Test leírás');
        $product->setPrice(1000);
        $product->setStock(10);
        $product->setCategory($category);

        $this->entityManager->persist($product);
        $this->entityManager->flush();

        $productId = $product->getId();
        $this->entityManager->remove($product);
        $this->entityManager->flush();

        $deletedProduct = $this->entityManager->getRepository(Product::class)->find($productId);
        $this->assertNull($deletedProduct);
    }

    public function test_product_stock_cannot_be_negative()
    {
        $this->expectException(\InvalidArgumentException::class);

        $category = new Category();
        $category->setName('Test kategória');
        $this->entityManager->persist($category);
        $this->entityManager->flush();

        $product = new Product();
        $product->setName('Test termék');
        $product->setDescription('Test leírás');
        $product->setPrice(1000);
        $product->setStock(-1); // Ez kivételt fog dobni
        $product->setCategory($category);

        $this->entityManager->persist($product);
        $this->entityManager->flush();
    }
} 